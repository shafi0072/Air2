# air-cnc

### Requirements
1. look at the screenshots one after another. 
2. All the resources under the images folder
4. We expect you to develop the main page
5. Create an integration with google map
6. allow user to filter result. 
7. payment integration
8. login
9. listing detail
10. checkout
